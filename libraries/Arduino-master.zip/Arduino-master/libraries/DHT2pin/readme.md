
# DHT2PIN library

## Description

NOTE: THIS LIB IS NOT TESTED EXTENSIVELY YET SO ALL DISCLAIMERS APPLY

This library is an experimental version of the DHT library that uses 2 pins instead of 1.
One pin for all read actions and one pin for write actions.

It was made after a request which also refered to the links below.

https://communities.intel.com/thread/53869
http://bigdinotech.com/tutorials/galileo-tutorials/using-1-wire-device-with-intel-galileo/


## Credits

Maria Emanuella Moura Silva for testing and verifying this experimental code on a Galileo.

## NOTE: THIS LIB IS NOT TESTED EXTENSIVELY YET SO ALL DISCLAIMERS APPLY

